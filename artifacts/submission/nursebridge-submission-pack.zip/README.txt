NurseBridge submission materials — refreshed September 29, 2026

nursebridge-pitch.pdf: seven-slide presentation with selectable text.
nursebridge-pitch.pptx: editable presentation.
nursebridge-cover.png: 1920 x 1080 cover.
submission-copy.txt: title, short description, long description and tags.
nursebridge-demo.mp4: 80-second narrated mock walkthrough, 1080p with captions.
nursebridge-demo.srt: external subtitles.

The walkthrough uses fictional transcript replay and current local UI screenshots.
It is not a live-provider or physical-device recording. Separate repository evidence
records the September 29 local AssemblyAI/Nebius test with recorded microphone inputs.

This packet is prepared locally and has not been submitted. It is not application
source. Public source access, a hosted interactive URL, event registration and the
signed-in submission form still need completion. Review event-specific requirements
before uploading each individual file. The PDF and video are separate form assets;
this convenience ZIP does not replace the source or interactive application links.
